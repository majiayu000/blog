import bpy, math, json, hashlib
from pathlib import Path
from mathutils import Vector
P=Path(__file__).resolve().parent
bpy.ops.object.select_all(action='SELECT'); bpy.ops.object.delete(use_global=False)
for d in list(bpy.data.materials): bpy.data.materials.remove(d)
s=bpy.context.scene
s.unit_settings.system='METRIC'
s.render.engine='CYCLES'; s.cycles.samples=24; s.cycles.use_denoising=True
s.render.resolution_x=1100; s.render.resolution_y=850; s.render.resolution_percentage=100
s.world.color=(0.24,0.24,0.24)
s.view_settings.view_transform='AgX'
s.render.image_settings.file_format='PNG'
s.render.film_transparent=False
bpy.context.preferences.filepaths.save_version=0
asset=bpy.data.collections.new('TANK • Moss T1'); s.collection.children.link(asset)
def mat(name,c,metal=0,rough=.45):
 m=bpy.data.materials.new(name); m.diffuse_color=(*c,1); m.use_nodes=True
 bs=m.node_tree.nodes.get('Principled BSDF'); bs.inputs['Base Color'].default_value=(*c,1); bs.inputs['Metallic'].default_value=metal; bs.inputs['Roughness'].default_value=rough
 return m
olive=mat('Armor • Moss green',(.20,.29,.17),.28)
dark=mat('Track • Graphite',(.038,.05,.054),.45)
rubber=mat('Rubber',(.019,.025,.027),0,.7)
edge=mat('Wheel hubs • Sage',(.37,.43,.26),.45)
orange=mat('Identification • Warm ivory',(.94,.73,.38),.1)
black=mat('Recess',(.008,.013,.018),.1)
glass=mat('Optics • Glacier',(.12,.58,.66),.7,.18)
steel=mat('Hardware',(.26,.3,.31),.7)
painted=[]
def finish(o,name,m,bev=0,parent=None):
 o.name=name
 for c in list(o.users_collection): c.objects.unlink(o)
 asset.objects.link(o)
 o.data.materials.append(m)
 if bev:
  md=o.modifiers.new('Soft machined edges','BEVEL'); md.width=bev; md.segments=3
  md=o.modifiers.new('Weighted surface normals','WEIGHTED_NORMAL')
 if parent: o.parent=parent
 if m==olive: painted.append(name)
 return o
root=bpy.data.objects.new('Tank_Root',None); asset.objects.link(root)
def box(n,loc,dim,m=olive,b=.04,parent=root):
 bpy.ops.mesh.primitive_cube_add(size=1,location=loc); o=bpy.context.object; o.dimensions=dim
 bpy.ops.object.transform_apply(location=False,rotation=True,scale=True)
 return finish(o,n,m,b,parent)
def cyl(n,loc,r,depth,m=steel,axis='Z',parent=root):
 bpy.ops.mesh.primitive_cylinder_add(vertices=48,radius=r,depth=depth,location=loc)
 o=bpy.context.object
 if axis=='Y': o.rotation_euler.x=math.pi/2
 if axis=='X': o.rotation_euler.y=math.pi/2
 bpy.ops.object.transform_apply(location=False,rotation=True,scale=True)
 for f in o.data.polygons: f.use_smooth=True
 return finish(o,n,m,.014,parent)
def frustum(n,z0,z1,bottom,top,m=olive,parent=root,cx=0):
 vs=[(cx+x*l/2,y*w/2,z) for z,(l,w) in [(z0,bottom),(z1,top)] for x,y in [(-1,-1),(-1,1),(1,1),(1,-1)]]
 faces=[(3,2,1,0),(4,5,6,7),(0,1,5,4),(1,2,6,5),(2,3,7,6),(3,0,4,7)]
 me=bpy.data.meshes.new(n); me.from_pydata(vs,[],[tuple(reversed(f)) for f in faces]); me.update(); o=bpy.data.objects.new(n,me); asset.objects.link(o)
 return finish(o,n,m,.07,parent)
box('Hull_Lower',(0,0,.79),(3.9,1.66,.66))
frustum('Hull_Upper',.94,1.49,(4.25,2.04),(3.5,1.86))
# Capsule track paths; individual linked shoes are grouped per side.
for side,y in [('L',-1.18),('R',1.18)]:
 tr=bpy.data.objects.new('Track_'+side,None); asset.objects.link(tr); tr.parent=root
 a=1.47; r=.55; z=.63
 points=[]
 for i in range(20): points.append((-a+2*a*i/20,z+r,0))
 for i in range(12):
  t=math.pi/2-math.pi*i/12; points.append((a+r*math.cos(t),z+r*math.sin(t),math.pi/2-t))
 for i in range(20): points.append((a-2*a*i/20,z-r,math.pi))
 for i in range(12):
  t=-math.pi/2-math.pi*i/12; points.append((-a+r*math.cos(t),z+r*math.sin(t),math.pi/2-t))
 for i,(x,zz,ang) in enumerate(points):
  o=box(f'Tread_{side}_{i:02}',(x,y,zz),(.148,.52,.125),dark,.018,tr); o.rotation_euler.y=ang
  o=box(f'Grip_{side}_{i:02}',(x,y,zz),(.055,.56,.151),steel,.009,tr); o.rotation_euler.y=ang
 for i,x in enumerate([-1.47,-.735,0,.735,1.47]):
  cyl(f'Wheel_{side}_{i}',(x,y,.63),.447,.41,rubber,'Y',tr)
  outer=y+(-.23 if y<0 else .23)
  cyl(f'WheelFace_{side}_{i}',(x,outer,.63),.337,.048,olive,'Y',tr)
  cyl(f'Hub_{side}_{i}',(x,outer+(-.035 if y<0 else .035),.63),.145,.075,edge,'Y',tr)
  for j in range(6):
   t=j*math.tau/6; cyl(f'Bolt_{side}_{i}_{j}',(x+.23*math.cos(t),outer+(-.03 if y<0 else .03),.63+.23*math.sin(t)),.025,.025,steel,'Y',tr)
 box('Fender_'+side,(0,y,1.285),(4.24,.69,.12),olive,.035)
 box('SideRail_'+side,(.15,y+(-.35 if y<0 else .35),1.22),(2.5,.055,.23),edge,.02)
cyl('Turret_Ring',(0,0,1.51),.80,.16,dark)
tur=bpy.data.objects.new('Turret_Assembly',None); asset.objects.link(tur); tur.parent=root
frustum('Turret_Armor',1.57,2.16,(2.03,1.72),(1.63,1.38),parent=tur,cx=.12)
box('Mantlet',(-.94,0,1.86),(.4,.67,.46),edge,.1,tur)
cyl('Barrel',(-1.82,0,1.88),.115,1.46,olive,'X',tur)
cyl('Barrel_Collar',(-1.2,0,1.88),.157,.26,edge,'X',tur)
box('Muzzle',(-2.66,0,1.88),(.3,.33,.27),dark,.05,tur)
box('Muzzle_Recess',(-2.812,0,1.88),(.006,.19,.12),black,.01,tur)
cyl('Hatch',(.28,-.08,2.20),.36,.10,edge,parent=tur)
box('Hatch_Handle',(.28,-.08,2.29),(.24,.055,.065),steel,.018,tur)
box('Periscope',(-.28,-.41,2.21),(.3,.18,.15),dark,.02,tur)
box('Periscope_Glass',(-.433,-.41,2.22),(.009,.14,.065),glass,.008,tur)
cyl('Antenna_Base',(.73,.42,2.15),.09,.15,dark,parent=tur)
cyl('Antenna',(.73,.42,2.59),.016,.78,steel,parent=tur)
for y in [-.72,.72]:
 box('Headlamp_Housing_'+str(y),(-1.80,y,1.36),(.20,.26,.20),dark,.04)
 box('Headlamp_'+str(y),(-1.908,y,1.36),(.012,.18,.12),orange,.02)
for i in range(7): box('Rear_Vent_'+str(i),(1.36+i*.065,0,1.5),(.028,1.00,.025),dark,.004)
for y in [-.72,.72]: box('Rear_Storage_'+str(y),(1.55,y,1.57),(.62,.35,.25),edge,.035)
# Painted accent stripe and a raised identification plate.
box('Turret_Accent',(.12,-.827,1.78),(.61,.018,.095),orange,.007,tur)
box('Front_Accent',(-1.98,0,1.20),(.025,.64,.09),orange,.01)
# Studio is excluded from asset exports.
floor_mat=mat('Studio • Warm grey',(.19,.22,.22),0,.8)
bpy.ops.mesh.primitive_plane_add(size=200,location=(0,0,-.015)); floor=bpy.context.object; floor.name='Studio_Floor'; floor.data.materials.append(floor_mat)
def aim(o,p): o.rotation_euler=(Vector(p)-o.location).to_track_quat('-Z','Y').to_euler()
for name,loc,power,size,col in [('Key',(-3,-5,7),1500,5,(1,.86,.70)),('Fill',(-1,5,5),1100,4,(.7,.84,1)),('Rim',(4,1,6),1800,3,(1,1,.9))]:
 bpy.ops.object.light_add(type='AREA',location=loc); o=bpy.context.object; o.name=name; o.data.energy=power; o.data.shape='DISK'; o.data.size=size; o.data.color=col; aim(o,(0,0,1))
bpy.ops.object.camera_add(location=(-6,-7,4.7)); cam=bpy.context.object; cam.name='Studio_Camera'; cam.data.type='ORTHO'; cam.data.ortho_scale=7.4; aim(cam,(-.3,0,1.1)); s.camera=cam
s['design']='MOSS T1 - fictional stylized tank, visual asset only'
def export(name):
 bpy.ops.object.select_all(action='DESELECT')
 for o in asset.objects: o.select_set(True)
 bpy.ops.export_scene.gltf(filepath=str(P/(name+'.glb')),export_format='GLB',use_selection=True,export_apply=True)
def render(name,loc,target=(-.3,0,1.1),scale=7.4):
 bpy.data.objects['Studio_Floor'].hide_render=('hero' not in name); s.render.film_transparent=('hero' not in name)
 cam.location=loc; aim(cam,target); cam.data.ortho_scale=scale; s.render.filepath=str(P/'renders'/(name+'.png')); bpy.ops.render.render(write_still=True)
base=P/'moss_t1_base.blend'
bpy.ops.wm.save_as_mainfile(filepath=str(base)); export('moss_t1_base')
render('base_hero',(-6,-7,4.7))
render('base_side',(0,-9,1.25),(-.3,0,1.3),6.9)
render('base_front',(-9,0,1.4),(-.3,0,1.4),5.3)
render('base_top',(0,0,10),(-.3,0,0),7.8)
# Reopen saved native scene before making the requested edit.
bpy.ops.wm.open_mainfile(filepath=str(base)); s=bpy.context.scene; cam=s.camera; asset=bpy.data.collections['TANK • Moss T1']
s['source_base_sha256']=hashlib.sha256(base.read_bytes()).hexdigest()
bar=bpy.data.objects['Barrel']; bar.dimensions.x+=.50; bar.location.x-=.25
for name in ['Muzzle','Muzzle_Recess']: bpy.data.objects[name].location.x-=.50
bpy.data.objects['Turret_Armor'].scale.y=1.18
bpy.data.objects['Turret_Accent'].location.y*=1.18
m=bpy.data.materials['Armor • Moss green']; m.name='Armor • Desert ochre'; c=(.57,.35,.14,1); m.diffuse_color=c; m.node_tree.nodes['Principled BSDF'].inputs['Base Color'].default_value=c
bpy.context.view_layer.update()
bpy.ops.wm.save_as_mainfile(filepath=str(P/'moss_t1_edited.blend')); export('moss_t1_edited'); render('edited_hero',(-6,-7,4.7))
print('BUILD_COMPLETE',flush=True)
