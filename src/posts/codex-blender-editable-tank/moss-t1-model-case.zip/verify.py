import bpy,json,hashlib
from pathlib import Path
P=Path(__file__).resolve().parent
records={}
for variant in ['base','edited']:
 bpy.ops.wm.open_mainfile(filepath=str(P/f'moss_t1_{variant}.blend'))
 obs=[o for o in bpy.data.collections['TANK • Moss T1'].objects if o.type=='MESH']
 records[variant]={'mesh_count':len(obs),'names':sorted(o.name for o in obs),'barrel_length':bpy.data.objects['Barrel'].dimensions.x,'barrel_diameter_y':bpy.data.objects['Barrel'].dimensions.y,'barrel_diameter_z':bpy.data.objects['Barrel'].dimensions.z,'turret_width':bpy.data.objects['Turret_Armor'].dimensions.y,'muzzle_x':bpy.data.objects['Muzzle'].location.x,'armor_color':list(bpy.data.objects['Turret_Armor'].active_material.diffuse_color),'source_base_sha256':bpy.context.scene.get('source_base_sha256')}
 for name in ['Track_L','Track_R','Turret_Assembly','Tank_Root']: assert name in bpy.data.objects
 assert len([o for o in obs if o.name.startswith('Tread_')])==128
 expected=set(o.name for o in obs)
 bpy.ops.wm.read_factory_settings(use_empty=True)
 bpy.ops.import_scene.gltf(filepath=str(P/f'moss_t1_{variant}.glb'))
 actual={o.name for o in bpy.context.scene.objects if o.type=='MESH'}
 assert expected==actual,(expected-actual,actual-expected)
 records[variant]['glb_roundtrip_mesh_count']=len(actual)
a,b=records['base'],records['edited']
assert a['names']==b['names']
for axis in ['y','z']: assert abs(a['barrel_diameter_'+axis]-b['barrel_diameter_'+axis])<1e-5
assert abs(b['barrel_length']-a['barrel_length']-.5)<1e-5
assert abs(b['turret_width']/a['turret_width']-1.18)<1e-5
assert abs(b['muzzle_x']-a['muzzle_x']+.5)<1e-5
assert b['armor_color']!=a['armor_color']
assert b['source_base_sha256']==hashlib.sha256((P/'moss_t1_base.blend').read_bytes()).hexdigest()
records['result']='PASS: native reopen, named parts, 128 treads, dimensional edits, recolor, base hash, both GLB roundtrips'
(P/'verification.json').write_text(json.dumps(records,indent=2))
print(records['result'])
print({k:{x:y for x,y in v.items() if x!='names'} for k,v in records.items() if isinstance(v,dict)})
