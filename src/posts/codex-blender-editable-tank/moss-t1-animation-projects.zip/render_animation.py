import bpy,json,shutil,time
from pathlib import Path
from mathutils import Vector
from bpy_extras.object_utils import world_to_camera_view
P=Path(__file__).resolve().parent
bpy.ops.wm.open_mainfile(filepath=str(P/'moss_t1_exploded_animation.blend'))
s=bpy.context.scene
prefs=bpy.context.preferences.addons['cycles'].preferences
prefs.compute_device_type='METAL'; prefs.get_devices()
assert any(d.type=='METAL' for d in prefs.devices),'Metal GPU required for this render configuration'
for d in prefs.devices: d.use=d.type=='METAL'
s.cycles.device='GPU';s.cycles.samples=12;s.render.use_persistent_data=True
# Widen framing slightly to leave room around every separated component.
cam=s.camera
keys=[]
for f in [1,30,108,150,192,264,288]:
 s.frame_set(f);keys.append((f,cam.data.ortho_scale*1.06))
for f,scale in keys:
 cam.data.ortho_scale=scale;cam.data.keyframe_insert(data_path='ortho_scale',frame=f)
parts=[o for o in bpy.data.collections['TANK • Moss T1'].objects if o.type=='MESH']
bounds=[1,0,1,0]
for f in range(1,289):
 s.frame_set(f)
 for o in parts:
  for corner in o.bound_box:
   v=world_to_camera_view(s,cam,o.matrix_world@Vector(corner))
   bounds=[min(bounds[0],v.x),max(bounds[1],v.x),min(bounds[2],v.y),max(bounds[3],v.y)]
assert bounds[0]>0 and bounds[1]<1 and bounds[2]>0 and bounds[3]<1,bounds
print('ALL_FRAME_BOUNDS',bounds,flush=True)
r=json.loads((P/'animation-verification.json').read_text());r['all_288_frames_in_camera']=True;r['normalized_camera_bounds']=bounds
(P/'animation-verification.json').write_text(json.dumps(r,indent=2))
s.frame_set(1);s.render.filepath=str(P/'animation-frames'/'frame_')
bpy.ops.wm.save_as_mainfile(filepath=str(P/'moss_t1_exploded_animation.blend'))
t=time.time()
for f in [1]+list(range(31,265)):
 s.frame_set(f);s.render.filepath=str(P/'animation-frames'/f'frame_{f:04}.png');bpy.ops.render.render(write_still=True)
 if f%12==0 or f==1:print('PROGRESS',f,'/ 288',round(time.time()-t,1),'seconds',flush=True)
for f in range(2,31):shutil.copyfile(P/'animation-frames'/'frame_0001.png',P/'animation-frames'/f'frame_{f:04}.png')
for f in range(265,289):shutil.copyfile(P/'animation-frames'/'frame_0264.png',P/'animation-frames'/f'frame_{f:04}.png')
assert all((P/'animation-frames'/f'frame_{f:04}.png').exists() for f in range(1,289))
print('ALL_288_FRAMES_READY',flush=True)
