import bpy, math, json
from pathlib import Path
from mathutils import Vector
P=Path(__file__).resolve().parent
bpy.ops.wm.open_mainfile(filepath=str(P/'moss_t1_base.blend'))
s=bpy.context.scene
s.render.engine='CYCLES'; s.cycles.samples=8; s.cycles.use_denoising=True
s.render.resolution_x=1280; s.render.resolution_y=720; s.render.resolution_percentage=100
s.render.fps=24; s.frame_start=1; s.frame_end=288
s.render.image_settings.file_format='PNG'
s.render.film_transparent=False
s.render.filepath=str(P/'animation-frames'/'frame_')
(P/'animation-frames').mkdir(exist_ok=True)
parts=sorted([o for o in bpy.data.collections['TANK • Moss T1'].objects if o.type=='MESH'],key=lambda o:o.name)
assert len(parts)==380
initial={o.name:o.location.copy() for o in parts}
def shift(o):
 n=o.name; x,y,z=o.location; side=-1 if y<0 else 1
 if n.startswith(('Tread_','Grip_')):
  return Vector((x*.45,side*(1.05 if n.startswith('Tread_') else 1.85),(z-.63)*.5+.7))
 if n.startswith('Wheel_'): return Vector((x*.45,side*2.6,.7))
 if n.startswith('WheelFace_'): return Vector((x*.45,side*3.25,.7))
 if n.startswith('Hub_'): return Vector((x*.45,side*3.8,.7))
 if n.startswith('Bolt_'): return Vector((x*.45,side*4.25,.7))
 if n=='Hull_Lower': return Vector((0,0,.25))
 if n=='Hull_Upper': return Vector((0,0,1.05))
 if n=='Turret_Ring': return Vector((0,0,1.65))
 if n=='Turret_Armor': return Vector((0,0,2.35))
 if n=='Mantlet': return Vector((-1.0,0,2.35))
 if n=='Barrel': return Vector((-1.8,0,2.35))
 if n=='Barrel_Collar': return Vector((-1.15,0,3.12))
 if n=='Muzzle': return Vector((-2.4,0,2.35))
 if n=='Muzzle_Recess': return Vector((-2.75,0,2.35))
 if n=='Hatch': return Vector((0,0,3.2))
 if n=='Hatch_Handle': return Vector((0,0,3.65))
 if n=='Periscope': return Vector((-.8,-.55,3.15))
 if n=='Periscope_Glass': return Vector((-1.1,-.55,3.15))
 if n=='Antenna_Base': return Vector((.9,.5,3.15))
 if n=='Antenna': return Vector((.9,.5,3.7))
 if n.startswith('Fender_'): return Vector((0,side*.7,1.4))
 if n.startswith('SideRail_'): return Vector((0,side*1.7,1.5))
 if n.startswith('Headlamp_Housing_'): return Vector((-.75,side*.25,1.1))
 if n.startswith('Headlamp_'): return Vector((-1.1,side*.25,1.1))
 if n.startswith('Rear_Vent_'): return Vector(((x-1.5)*2+.65,0,1.5))
 if n.startswith('Rear_Storage_'): return Vector((1.2,side*.45,1.8))
 if n=='Turret_Accent': return Vector((0,-.7,2.35))
 if n=='Front_Accent': return Vector((-.6,0,1.0))
 raise RuntimeError('Unassigned part: '+n)
for o in parts:
 a=initial[o.name]; delta=shift(o)
 assert delta.length>.1
 for frame,v in [(1,a),(30,a),(108,a+delta),(192,a+delta),(264,a),(288,a)]:
  o.location=v; o.keyframe_insert(data_path='location',frame=frame,group='Explosion')
# Camera eases outward, then moves around the fully expanded assembly.
cam=s.camera
for frame,angle,scale,targetz in [(1,math.radians(48),8.6,1.2),(30,math.radians(48),8.6,1.2),(108,math.radians(48),17.3,2.9),(150,math.radians(65),17.3,2.9),(192,math.radians(92),17.3,2.9),(264,math.radians(48),8.6,1.2),(288,math.radians(48),8.6,1.2)]:
 cam.location=(-13*math.cos(angle),-13*math.sin(angle),targetz+7.2)
 cam.rotation_euler=(Vector((-.3,0,targetz))-cam.location).to_track_quat('-Z','Y').to_euler()
 cam.data.ortho_scale=scale
 cam.keyframe_insert(data_path='location',frame=frame); cam.keyframe_insert(data_path='rotation_euler',frame=frame); cam.data.keyframe_insert(data_path='ortho_scale',frame=frame)
# Larger softboxes keep separated small components legible.
for name in ['Key','Fill','Rim']:
 o=bpy.data.objects[name]; o.location.z+=3; o.data.energy*=1.7; o.data.size*=1.3
s['animation_description']='380 individually animated meshes. Hold, explode, orbit, reassemble. 24 fps / 12 seconds.'
s.frame_set(1)
bpy.ops.wm.save_as_mainfile(filepath=str(P/'moss_t1_exploded_animation.blend'))
# Verify actual evaluated animation positions, including exact reassembly.
s.frame_set(144)
assert all((o.location-initial[o.name]).length>.1 for o in parts)
expanded={o.name:list(o.location) for o in parts}
s.frame_set(288)
assert all((o.location-initial[o.name]).length<1e-5 for o in parts)
(P/'animation-verification.json').write_text(json.dumps({'mesh_count':len(parts),'animated_parts':len(parts),'fps':24,'frames':288,'seconds':12,'all_parts_separate_at_frame_144':True,'all_parts_reassembled_at_frame_288':True,'expanded_locations':expanded},indent=2))
# Preview before rendering all frames.
s.frame_set(144); s.cycles.samples=24; s.render.filepath=str(P/'renders'/'exploded_preview.png'); bpy.ops.render.render(write_still=True)
print('ANIMATION_READY',flush=True)
