Blender animation project
Open moss_t1_blender_presentation.blend. Frame 1: assembled; frame 144: exploded; frame 288: reassembled. Space plays animation.
The .blend files are ready to edit. explode.py additionally requires moss_t1_base.blend from the modeling download. render_animation.py is the original macOS Metal render script and writes outputs beside itself; it modifies its output project and camera framing. Keep original files backed up before rerunning scripts.
