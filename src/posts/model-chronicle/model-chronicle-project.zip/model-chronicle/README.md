# 模型编年史：从看见，到行动

一部 142 秒、1920 × 1080、30 fps 的中文动态小展览。用像素猫、注意力连线、掩码填词、去噪画面和推理路径，串起 2012—2026 的精选 AI 里程碑，更新至 2026 年 10 月 6 日。配乐为本项目原创的程序合成音乐，无旁白。

## 播放与编辑

直接播放新版 `model-chronicle-2026.mp4`；原来的 `model-chronicle.mp4` 也已同步更新为新版。`index.html` 是可编辑的 HyperFrames 工程：文字、SVG 图形和所有动画都在一个文件里，音乐与动画库已保存在 `assets/`，运行时不需要远程素材。

环境要求：Node.js 22+、FFmpeg，以及 HyperFrames 支持的 Chrome/Chromium。

在本目录运行：

```sh
npx --yes hyperframes@0.8.137 preview . --background
```

在打开的 Studio 里播放、拖动时间线、修改文字和元素。HTML 动画需要 HyperFrames 的时间驱动，请使用 Studio 预览。

检查和重新导出：

```sh
npx --yes hyperframes@0.8.137 check .
npx --yes hyperframes@0.8.137 render . --quality delivery --fps 30 --workers 4 --output model-chronicle.mp4
```

## 章节

| 时间 | 内容 |
| --- | --- |
| 00:00 | 开篇：模型编年史 |
| 00:06 | 2012：AlexNet，图像识别 |
| 00:12 | 2017：Transformer，注意力 |
| 00:20 | 2018：BERT，双向语境 |
| 00:26 | 2020：GPT-3，规模与少样本学习 |
| 00:33 | 2022.08：Stable Diffusion，文生图 |
| 00:39 | 2022.11：ChatGPT，对话入口 |
| 00:46 | 2023：LLaMA / GPT-4，生态与能力 |
| 00:53 | 2024.05：GPT-4o，多模态交互 |
| 00:58 | 2024.09：o1-preview，推理 |
| 01:03 | 2025.01：DeepSeek-R1，开放推理 |
| 01:09 | 2025.03—08：Gemini 2.5 / Claude 4 / GPT-5，推理与编码 |
| 01:18 | 2026.04：DeepSeek-V4 预览版，百万上下文 |
| 01:25 | 2026.05—07：Gemini 3.5 / 3.6 Flash，智能走向行动 |
| 01:33 | 2026.09.01：Claude Fable 5.1，长任务 |
| 01:41 | 2026.09.10：DeepSeek-V4.1-Flash，持续迭代 |
| 01:48 | 2026.09：GPT-6 / GPT-6.1 Sol，模型家族 |
| 02:00 | 2026.09.30：Gemini 4 Argon，分阶段开放 |
| 02:08 | 截至 2026.10.06：已核实的代表版本 |
| 02:16 | 尾声：下一章，也属于使用模型的人 |

## 原始资料与选取范围

本片为策展式选集，覆盖 2012 年至 2026 年 10 月 6 日已核实的代表发布；不是所有模型和补丁版本的完整名录。2025 年的 Gemini 2.5 首发为 Pro Experimental；2026 年的 DeepSeek-V4 首发为预览版，V4-Pro 的正式发布在 8 月 13 日。Transformer 是架构，ChatGPT 是基于模型的产品，片中将两者纳入能力与交互发展的里程碑。年份按论文首发或所述产品公开发布区分。

所有图形、对话、填词与路线均为概念示意，不是实际模型输出、注意力权重或内部推理过程。主线“从看见，到行动”是创作叙事，不表示后出现的能力取代此前能力。LLaMA 初代向研究社区发布，不意味着初代采用不受限制的开源许可证。

- AlexNet / 2012：[ImageNet Classification with Deep Convolutional Neural Networks](https://papers.nips.cc/paper_files/paper/2012/hash/c399862d3b9d6b76c8436e924a68c45b-Abstract.html)
- Transformer / 2017.06.12：[Attention Is All You Need](https://arxiv.org/abs/1706.03762)
- BERT / 2018.10.11：[BERT: Pre-training of Deep Bidirectional Transformers](https://arxiv.org/abs/1810.04805)
- GPT-3 / 2020.05.28：[Language Models are Few-Shot Learners](https://arxiv.org/abs/2005.14165)
- Stable Diffusion / 2022.08.22：[Stable Diffusion Public Release](https://stability.ai/news-updates/stable-diffusion-public-release)
- ChatGPT / 2022.11.30：[Introducing ChatGPT](https://openai.com/index/chatgpt/)
- LLaMA / 2023.02.27（论文）：[LLaMA: Open and Efficient Foundation Language Models](https://arxiv.org/abs/2302.13971)
- GPT-4 / 2023.03.14：[GPT-4](https://openai.com/index/gpt-4-research/)
- GPT-4o / 2024.05.13：[Hello GPT-4o](https://openai.com/index/hello-gpt-4o/)
- o1-preview / 2024.09.12：[Introducing OpenAI o1-preview](https://openai.com/index/introducing-openai-o1-preview/)
- DeepSeek-R1 / 2025.01.20：[DeepSeek-R1 Release](https://api-docs.deepseek.com/news/news250120/)

- Gemini 2.5 Pro Experimental / 2025.03.25：[Google 官方发布](https://blog.google/innovation-and-ai/models-and-research/google-deepmind/gemini-model-thinking-updates-march-2025/)
- Claude Opus 4 / Sonnet 4 / 2025.05.22：[Introducing Claude 4](https://www.anthropic.com/news/claude-4)
- GPT-5 / 2025.08.07：[Introducing GPT-5](https://openai.com/index/introducing-gpt-5/)
- DeepSeek-V4 Preview / 2026.04.24：[V4 Preview Release](https://api-docs.deepseek.com/news/news260424/)
- Gemini 3.5 Flash / 2026.05.19：[Gemini 3.5: frontier intelligence with action](https://blog.google/innovation-and-ai/models-and-research/gemini-models/gemini-3-5/)
- Claude Opus 5 / 2026.07.24：[Introducing Claude Opus 5](https://www.anthropic.com/news/claude-opus-5)
- Gemini 3.6 Flash / 2026.07.31（官方公告日期）：[July Gemini Drop](https://blog.google/products-and-platforms/products/gemini/gemini-drop-july-2026/)
- DeepSeek-V4-Pro GA / 2026.08.13：[GA Release](https://api-docs.deepseek.com/news/news260813/)
- Claude Fable 5.1 / 2026.09.01：[官方日期索引](https://www.anthropic.com/claude/fable)、[Fable 5.1 / Mythos 5.1 发布说明](https://www.anthropic.com/claude-fable-and-mythos-5-1)。Fable 5.1 普遍可用，Mythos 5.1 为受限访问；本片代表版本采用 Fable。
- GPT-6 Astra / 2026.09.03：[GPT-6 Astra](https://openai.com/index/gpt-6-astra/)、[日期索引](https://openai.com/news/research/)
- DeepSeek-V4.1-Flash / 2026.09.10：[官方发布](https://api-docs.deepseek.com/news/news260910)、[可读取的官方发布索引](https://api-docs.deepseek.com/news/news260813/)。本片仅据官方索引使用版本名称与发布日期，没有为该版本添加性能数字。
- GPT-6 Sol / Luna / 2026.09.22：[Introducing GPT-6 Sol and Luna](https://openai.com/index/introducing-gpt-6-sol-and-luna/)
- GPT-6.1 Sol / 2026.09.29：[Introducing GPT-6.1 Sol](https://openai.com/index/introducing-gpt-6-1-sol/)、[日期索引](https://openai.com/news/research/)

- Gemini 4 Argon / 2026.09.30：[Introducing Gemini 4 Argon](https://blog.google/innovation-and-ai/models-and-research/gemini-models/gemini-4-argon/)。官方说明当前向可信网络安全防御者分阶段开放，尚未普遍可用。

资料核实截止日期：2026-10-06。片尾的 2026.10.06 是本作品的核实日期，不是右侧各模型的发布日期。

## 验证

底部年份线按当前章节年份推进，橙色线与圆点使用同一章节位置和过渡时长；进入 2026 章节后，两者均到达 2026。最右侧保留空心 2027 刻度，表示下一年，橙色线不进入该段。视频播放器自身的进度条继续表示播放时间。

新增 2027 刻度后，HyperFrames 在 5 个代表时间点进行检查：运行错误与警告均为 0，布局错误与警告均为 0，115 项文字对比度检查全部通过。检查保留了 21 项单文件工程组织建议，不影响成片播放；此工程为方便修改，保留了单文件结构。

成片核验：H.264 视频，1920 × 1080，30 fps，4260 帧，时长 142 秒；AAC 音轨同为 142 秒。已检查片头、9 月新增章节、截至今日版本表和最后一帧，音轨峰值为 -7.5 dBFS。

## 工具与素材

- 使用 [HyperFrames](https://github.com/heygen-com/hyperframes) CLI 0.8.137 进行检查、预览和视频渲染；框架采用 Apache-2.0 许可证。
- 随工程提供 GSAP 3.14.2；原文件声明保留于 `assets/gsap.min.js` 文件头，适用 [GSAP Standard License](https://gsap.com/standard-license/)。HyperFrames 的许可证不改变 GSAP 的许可证。
- 所有 SVG 图形及配乐均在本项目中原创；中文字体使用系统字体，导出视频已包含渲染后的字形。
